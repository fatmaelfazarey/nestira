import{j as s}from"./index-CDa0BP53.js";const t=()=>s.jsx("div",{children:"update-password"});export{t as default};
