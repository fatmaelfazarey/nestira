import{j as t}from"./index-CDa0BP53.js";const r=()=>t.jsx("div",{children:"Contact us"});export{r as default};
