import{j as t}from"./index-CDa0BP53.js";const o=()=>t.jsx("div",{children:"AboutPage"});export{o as default};
