import{j as s}from"./index-CDa0BP53.js";const o=()=>s.jsx("div",{children:"JobsPage"});export{o as default};
