const c="/assets/56e3e265-35c1-4968-86ec-2a6c964c97ad-D6-xtxrn.png";export{c as l};
